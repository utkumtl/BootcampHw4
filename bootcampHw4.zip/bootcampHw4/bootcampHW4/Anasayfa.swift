//
//  ViewController.swift
//  bootcampHW4
//
//  Created by Utku Mutlu on 30.09.2022.
//

import UIKit

class Anasayfa: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonAgecis(_ sender: Any) {
        performSegue(withIdentifier: "SayfaAGecis", sender: nil)
    }
    
    @IBAction func buttonXgecis(_ sender: Any) {
        performSegue(withIdentifier: "SayfaXGecis", sender: nil)
    }
}

