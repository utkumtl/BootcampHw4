//
//  SayfaY.swift
//  bootcampHW4
//
//  Created by Utku Mutlu on 30.09.2022.
//


import UIKit

class SayfaY: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonAnasayfaGecis(_ sender: Any) {
        navigationController?.popToRootViewController(animated: true)
        
    }
    
}
