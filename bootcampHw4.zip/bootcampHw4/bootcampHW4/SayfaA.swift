//
//  SayfaA.swift
//  bootcampHW4
//
//  Created by Utku Mutlu on 30.09.2022.
//

import UIKit

class SayfaA: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func buttonBGecis(_ sender: Any) {
        
        performSegue(withIdentifier: "SayfaBGecis", sender: nil)
    }
    
    
}
