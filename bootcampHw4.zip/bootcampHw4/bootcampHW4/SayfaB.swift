//
//  SayfaB.swift
//  bootcampHW4
//
//  Created by Utku Mutlu on 30.09.2022.
//

import UIKit

class SayfaB: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonYGecis(_ sender: Any) {
        performSegue(withIdentifier: "SayfaYGecis", sender: nil)
    }
    
}
